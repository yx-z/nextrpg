"""
PyRPGMaker - A Python-based RPG Maker tool
"""

__version__ = "0.1.0" 